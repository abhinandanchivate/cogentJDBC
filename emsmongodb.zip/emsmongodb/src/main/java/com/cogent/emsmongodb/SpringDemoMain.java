package com.cogent.emsmongodb;

import java.util.Date;

import javax.sql.DataSource;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.cogent.emsmongodb.config.Config;
import com.cogent.emsmongodb.config.DBConfig;
import com.cogent.emsmongodb.dto.Employee;
import com.cogent.emsmongodb.service.EmployeeService;
import com.cogent.emsmongodb.utils.BeanOne;
import com.cogent.emsmongodb.utils.BeanTwo;

public class SpringDemoMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// to get that object 
		// we have 2 ways (containers ====> where spring will manage the object life cycle
		
		// bean factory
		// application context
		//
		ApplicationContext applicationContext = new AnnotationConfigApplicationContext(Config.class);

		System.out.println("hello from application context");
//		EmployeeService employeeService = applicationContext.getBean(EmployeeService.class);
//		String result = employeeService.addEmployee(new Employee("ab0010", "abhi", "chivate", new Date(), new Date(), 1000.0f));
//		
//		System.out.println(result);
		
		//BeanTwo beanTwo = applicationContext.getBean(BeanTwo.class);
		
		//beanTwo.doSomthing();
		
		BeanOne beanOne = applicationContext.getBean(BeanOne.class);
		beanOne.doSomthing();
		
	}

}
