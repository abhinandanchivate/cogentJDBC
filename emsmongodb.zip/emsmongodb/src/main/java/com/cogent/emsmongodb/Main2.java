package com.cogent.emsmongodb;

import java.util.Scanner;

public class Main2 {

	public static void main(String[] args) {

		// TODO Auto-generated method stub

		Scanner scanner = new Scanner(System.in);
		
		System.out.println("enter the date");
		String str = scanner.next();
		
		String s[] = str.split("-");
		
		
		System.out.println(str);
	}

}
