package com.cogent.emsmongodb.repository;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.cogent.emsmongodb.dto.Employee;
import com.cogent.emsmongodb.utils.DBUtils;
import com.mysql.cj.protocol.Resultset;
@Repository
public class EmployeeRepositoryImpl implements EmployeeRepository {

	// can u implement singleton DP.

	

	@Autowired
	DBUtils dbUtils;

	@Override
	public String addEmployee(Employee employee) {
		// TODO Auto-generated method stub

		Connection connection = dbUtils.getConnection();

		String insertStatement = "insert into employee (empId,empFirstName, empLastName,doj,dob,empSalary) values(?,?,?,?,?,?)";

		PreparedStatement preparedStatement = null;

		try {
			preparedStatement = connection.prepareStatement(insertStatement);

			preparedStatement.setString(1, employee.getEmpId());
			preparedStatement.setString(2, employee.getEmpFirstName());
			preparedStatement.setString(3, employee.getEmpLastName());
			preparedStatement.setDate(4, new Date(employee.getDoj().getTime()));

			// can u provide the values accordingly
			preparedStatement.setDate(5, new Date(employee.getDob().getTime()));
			preparedStatement.setFloat(6, employee.getEmpSalary());

			int res = preparedStatement.executeUpdate();
			// no of rows affected by the statement will be returned

			if (res > 0) {
				return "success";
			} else {
				return "fail";
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			dbUtils.closeConnection(connection);
		}

		return null;
	}

	@Override
	public String deleteEmployeeById(String id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void deleteAllEmployees() {
		// TODO Auto-generated method stub

	}

	@Override
	public Optional<Employee> getEmployeeById(String id) {

		Connection connection = dbUtils.getConnection();
		//ArrayList<Employee> arrayList = new ArrayList<>();

		String query = "select * from employee where empId=?";
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;

		try {
			preparedStatement = connection.prepareStatement(query);
			preparedStatement.setString(1, id);

			resultSet = preparedStatement.executeQuery();

			if (resultSet.next()) {

				Employee employee = new Employee();

				employee.setEmpId(resultSet.getString("empId"));
				employee.setEmpFirstName(resultSet.getString("empFirstName"));
				employee.setEmpLastName(resultSet.getString("empLastName"));
				employee.setEmpSalary(resultSet.getFloat("empSalary"));
				employee.setDob(resultSet.getDate("dob"));
				employee.setDoj(resultSet.getDate("doj"));
				return Optional.ofNullable(employee);
				//arrayList.add(employee);

			}
//			
//			if(arrayList.isEmpty())
//			{
//				return Optional.empty();
//			}
//			else {
//				return Optional.of(arrayList);
//			}

			
//					// empty : returning null
			// of : if u r confirm about the object (its not empty/ not null )
			// ofNullable dicy

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		finally {
			dbUtils.closeConnection(connection);
		}

		return Optional.empty();

	}

	@Override
	public Optional<List<Employee>> getEmployees() {
		// TODO Auto-generated method stub

		Connection connection = dbUtils.getConnection();
		ArrayList<Employee> arrayList = new ArrayList<>();

		String query = "select * from employee";
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;

		try {
			preparedStatement = connection.prepareStatement(query);

			resultSet = preparedStatement.executeQuery();

			while (resultSet.next()) {

				Employee employee = new Employee();

				employee.setEmpId(resultSet.getString("empId"));
				employee.setEmpFirstName(resultSet.getString("empFirstName"));
				employee.setEmpLastName(resultSet.getString("empLastName"));
				employee.setEmpSalary(resultSet.getFloat("empSalary"));
				employee.setDob(resultSet.getDate("dob"));
				employee.setDoj(resultSet.getDate("doj"));

				arrayList.add(employee);

			}
//			
//			if(arrayList.isEmpty())
//			{
//				return Optional.empty();
//			}
//			else {
//				return Optional.of(arrayList);
//			}

			return Optional.ofNullable(arrayList);
//					// empty : returning null
			// of : if u r confirm about the object (its not empty/ not null )
			// ofNullable dicy

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		finally {
			dbUtils.closeConnection(connection);
		}

		return Optional.empty();
	}

	@Override
	public String updateEmployee(String id, Employee employee) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean isEmployeeExists(String id) {
		// TODO Auto-generated method stub
		return false;
	}

}
