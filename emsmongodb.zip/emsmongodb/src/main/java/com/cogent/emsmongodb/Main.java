package com.cogent.emsmongodb;

import java.time.LocalDate;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.Scanner;

import com.cogent.emsmongodb.dto.Employee;
import com.cogent.emsmongodb.service.EmployeeService;
import com.cogent.emsmongodb.service.EmployeeServiceImpl;

public class Main {

	public static void main(String[] args) {
		
		EmployeeService employeeService=  EmployeeServiceImpl.getInstance();
		
		Scanner scanner = new Scanner(System.in);
		
		Employee employee = new Employee("ab002", "abhinandan", "chivate",
				new Date(), new Date(1988, 11, 9),  1000.0f);
		
		String result = employeeService.addEmployee(employee);
		
		if("success".equals(result)) {
			System.out.println("record added successfully");
		}
		else {
			System.out.println("problem");
		}
		
		Optional<List<Employee>> optional = employeeService.getEmployees();
		
		
		if(optional.isPresent()) {
			optional.get().forEach(System.out::println);
		}
		
	}
}
