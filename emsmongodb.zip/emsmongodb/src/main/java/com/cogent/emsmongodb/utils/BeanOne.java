package com.cogent.emsmongodb.utils;

import org.springframework.beans.factory.annotation.Autowired;

public class BeanOne {
	BeanTwo beanTwo ;
	
	
	public BeanOne(BeanTwo beanTwo) {
		 
		 this.beanTwo = beanTwo;
	      System.out.println("BeanOne Initialized");
	   }

	   public void doSomthing() {
		   beanTwo.doSomthing();
	      System.out.println("Inside doSomthing() method of BeanOne");
	   }
}
